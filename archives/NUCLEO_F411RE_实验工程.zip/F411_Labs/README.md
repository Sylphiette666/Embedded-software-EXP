# NUCLEO-F411RE 嵌入式实验工程

本工程对应《嵌入式系统实验指导书》的八个实验，已将 STM32F103 平台移植为 STM32F411RET6。另提供一个无需外接器件的演示程序。正式实验与单板演示分开，不能把单键长短按替代方案当作指导书要求的双键验收。

## 现在如何使用

1. 用 Keil 5 打开 `MDK/F411_Labs.uvprojx`。
2. 在 Target 下拉框选择对应实验；仅有开发板时先选择 `09_BoardOnly_Demo`。
3. 按 F7 编译。使用已安装的 Arm Compiler 6.24 和 STM32F4xx_DFP 2.17.1。
4. 工程已配置 ST-Link、SWD 和 STM32F4xx 512KB Flash 算法。换电脑后可在 Options for Target → Debug / Utilities 中核对。Flash 地址为 0x08000000，容量 0x80000。
5. Download 下载，按黑色 RESET 复位启动；结束调试时确保程序恢复运行。
6. 串口助手选择 COM3、115200、8N1、无流控、文本模式。中文显示选择 UTF-8。COM 号在换 USB 接口后可能变化。

板载 ST-Link 同时提供 SWD 和虚拟串口，不需要另购下载器。ST-Link 下载属于实验一的 SWD 下载部分，不能替代该实验另行要求的 UART ISP 下载。

也可以直接在 PowerShell 中下载已编译的演示程序并打开串口：

```powershell
powershell -ExecutionPolicy Bypass -File D:\MDK5\F411_Labs\tools\flash.ps1 -Lab 9
powershell -ExecutionPolicy Bypass -File D:\MDK5\F411_Labs\tools\serial_console.ps1 -Port COM3
```

`-Lab` 可选择 1～9。串口窗口按 Esc 关闭，使用其他串口助手前先释放 COM3。

## 仅开发板演示

`09_BoardOnly_Demo` 上电默认熄灯。

| 操作 | 结果 |
|---|---|
| 短按蓝色 B1，松开 | 开启或停止闪烁；停止时立即熄灭 |
| 持续按住 B1 至少 0.8 秒 | 串口输出“嵌入式实验完成啦”，松开时不切换闪烁 |
| 串口发送 Y | 停止闪烁，LD2 常亮 |
| 串口发送 N | 停止闪烁，LD2 熄灭 |
| 串口发送 B | 开启或停止闪烁 |
| 串口发送 M | 输出中文消息，用于验证显示和编码 |
| 串口发送 ? | 输出毫秒计数、灯状态、按键电平、中断计数和串口错误计数 |

B1 按下通过 EXTI13 记录事件，20 ms 消抖、长按判定和字符串发送在主循环完成。串口 M 用于联调，不能当作实体按键中断验收。

## 引脚与补充器件

| 名称 | 引脚 | 连接和有效电平 |
|---|---|---|
| LED0 | PA5 | 板载绿色 LD2，高电平亮 |
| LED1 | PA6 / Arduino D12 | 外接 330Ω 电阻和 LED 到 GND，高电平亮 |
| KEY0 | PC13 | 板载蓝色 B1 USER，按下为低 |
| KEY1 | PA0 / Arduino A0 | 外接按键到 GND，内部上拉，按下为低 |
| USART2 TX | PA2 | 默认连接 ST-Link 虚拟串口 |
| USART2 RX | PA3 | 默认连接 ST-Link 虚拟串口 |

外设接线（断电后操作）：

```text
PA6 / D12 -- 330Ω -- LED 阳极（长脚）
                     LED 阴极（短脚） -- GND

PA0 / A0  -- 按键 -- GND
```

四脚轻触按键要连接按下时才导通的两组触点。黑色 RESET 只用于复位。PA13、PA14 保留给 SWD。板上的电源灯和 ST-Link 指示灯不能作为第二个目标 MCU 用户 LED。

## 各实验如何验收

| Target | 实现 | 当前只有开发板时的限制 |
|---|---|---|
| 01_Platform | LD2 每 500 ms 翻转，串口启动信息与状态查询 | SWD 下载已可执行；UART ISP 需另外验证 |
| 02_Register | 直接操作 RCC、MODER、OTYPER、PUPDR、BSRR，使 PA5/PA6 交替输出 | PA6 有输出但没有第二个实体 LED；不能拍到完整双灯现象 |
| 03_StdPeriph | 通过标准外设库控制 LD2 亮 1 秒、灭 1 秒 | 无外设要求 |
| 04_Keys | KEY0 同时翻转两灯；KEY1 在一亮一灭之间切换 | B1 可用，第二灯和第二按键缺失 |
| 05_EXTI | PC13/EXTI13 翻转 PA5；PA0/EXTI0 翻转 PA6 | B1 分支可用；第二路实体按键与灯缺失 |
| 06_USART | 大写 Y 点亮 LD2，N 熄灭；其他字符不改变状态 | 无外设要求 |
| 07_SysTick | 1 ms 系统计时，每 1000 ms 翻转 LD2 | 无外设要求；精度验收需要计时仪器 |
| 08_Application | B1 开关闪烁；外接 PA0 按键以中断方式触发中文显示 | 第二按键缺失；“屏幕”暂实现为电脑串口窗口 |
| 09_BoardOnly_Demo | 单板的短按、长按、串口与定时综合演示 | 是联调补充，不是第八实验的完整替代 |

实验四初始两灯全灭。KEY0 分别反转两灯当前值，因此可能得到“两灯全亮”或“两灯全灭”；KEY1 独立在互斥状态间切换。两个按键几乎同时按下时先处理 KEY0，再处理 KEY1。

## 工程结构与原理

```text
App/platform.c          GPIO、串口、SysTick、消抖与中断驱动
App/platform.h          公共接口、状态变量
App/system_lab.c        系统启动，内部 HSI 16 MHz
App/stm32f4xx_conf.h     标准库模块配置
Labs/01_.../main.c       各实验独立主程序
MDK/F411_Labs.uvprojx    九个 Target 的 Keil 工程
MDK/flash.sct           512 KB Flash / 128 KB SRAM 链接配置
Vendor/                 ST SPL 1.8.0 和 Arm CMSIS 5.9 的源文件
Build/                  AXF、HEX、BIN、编译日志、测试记录
Backup/                 首次修改前的完整 Flash 备份
docs/                   实验报告草稿与验收说明
tools/                  编译、下载与验证脚本
```

所有实验均使用 F4 标准外设库，不依赖 HAL 或 RTOS。实验二的 LED 初始化与输出直接操作寄存器；其串口提示和公共计时函数仅辅助观察。

时钟选择内部 HSI，AHB/APB1/APB2 都不分频，避免依赖外部晶振或板卡焊桥。SysTick 重装值为 15999，每 16000 个内核时钟产生一次中断，标称 1 ms。HSI 存在频率容差，不能将毫秒计数等同于经仪器校准的绝对时间。需要高精度测量时应配置并核实板载外部时钟源，再用示波器或逻辑分析仪测量输出。

GPIO 时钟位于 AHB1。外部中断使用 SYSCFG 映射到 EXTI，PC13 对应 EXTI15_10_IRQHandler，PA0 对应 EXTI0_IRQHandler。中断函数只清标志、记录事件，不在其中等待按键松开或执行长延时。SysTick 中断只更新计数；串口接收中断放入 128 字节环形缓冲区，主循环执行命令。

## 下载与恢复

可用 Keil/ST-Link 下载 `Build/Keil_*/` 的 HEX 或 AXF；`Build/01_Platform/` 等目录也提供通过命令行编译的 HEX、BIN、AXF。两套构建都使用同一源代码。

当前板子的原始 Flash 已保存到 `Backup/original_flash_08000000.bin`，备份地址 0x08000000，长度 0x80000。恢复时使用 STM32CubeProgrammer 或支持 BIN 的烧录工具，指定基地址 0x08000000 并校验。备份不包括 option bytes；本任务没有修改 option bytes。

实验一的 ISP 部分：按 F411 官方 Bootloader 文档核实 UART 引脚及启动条件，设置 BOOT0 后复位进入系统存储器，通过串口下载，再恢复 BOOT0=0 并复位。FlyMcu 对 F411 的识别能力需要实测；若无法识别，可使用 STM32CubeProgrammer 的 UART 功能。设备管理器中出现 ST-Link COM 口不代表已经进入 ISP 模式。此部分未完成时，应在报告中保留“待验收”。

## 编译和检查

常规操作直接在 Keil 中选 Target 并按 F7。命令行编译可使用：

```powershell
python tools/build.py --compiler D:/Keil5/ARM/ARMCLANG/bin
```

`build.py` 只使用 Python 标准库。`build_keil.py` 调用本机 Keil 检查全部 Target。调试测试脚本需要 pyocd、pyserial、libusb-package，运行会替换板上固件；日常使用无需运行这些自动化脚本。命令行 armasm 提示传统汇编器弃用属于工具迁移提示，Keil 构建结果另见 `Build/keil_results.json`。

## 故障排查

- 编译找不到头文件：保持整个工程目录结构，不要只拷贝 main.c。
- 出现多个 main：使用本工程的 Target 文件选择配置，每个 Target 只能启用一个实验入口。
- 无法识别芯片：确认安装 STM32F4xx_DFP、板载 ST-Link 跳线完整、使用数据线而非仅充电线。
- 串口无输出：确认 COM 号、115200 8N1，关闭占用串口的其他工具，连接后按 RESET。
- 中文乱码：选择 UTF-8。固件使用固定 UTF-8 字节序列，避免编辑器编码改变消息。
- 按一次翻转多次：核对接线和消抖；保持本工程“稳定 20 ms 后触发一次、松开后重新触发”的行为。
- 与指导书灯的电平相反：Nucleo 的 LD2 高电平亮，不能沿用 F103 mini/精英板的低电平点灯假设。

## 资料

- [NUCLEO-F411RE 官方页面](https://www.st.com/en/evaluation-tools/nucleo-f411re.html)
- [Nucleo-64 用户手册 UM1724](https://www.st.com/resource/en/user_manual/dm00105823.pdf)
- [STM32F411 参考手册 RM0383](https://www.st.com/resource/en/reference_manual/rm0383-stm32f411xce-advanced-armbased-32bit-mcus-stmicroelectronics.pdf)
- [STM32F4 标准外设库](https://www.st.com/en/embedded-software/stsw-stm32065.html)

第三方源码保留原作者声明和许可证；来源、版本及 SHA256 见 `Vendor/manifest.json` 和 `Vendor/README.md`。
