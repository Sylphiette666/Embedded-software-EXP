"""Validate each target using uVision itself, with its window hidden."""
from pathlib import Path
import subprocess
import json
ROOT=Path(__file__).resolve().parents[1]
startup=subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow=0
results=[]
for lab in sorted((ROOT/'Labs').iterdir()):
    if not lab.is_dir():continue
    log=ROOT/'Build'/('keil_'+lab.name+'.log')
    p=subprocess.run([r'D:\Keil5\UV4\UV4.exe','-b',str(ROOT/'MDK/F411_Labs.uvprojx'),
        '-t',lab.name,'-o',str(log),'-j0'],startupinfo=startup,cwd=ROOT/'MDK')
    text=log.read_bytes().decode('utf-8',errors='replace')
    ok='0 Error(s), 0 Warning(s).' in text
    print(lab.name, 'PASS' if ok else 'FAIL')
    results.append({'target':lab.name,'exit_code':p.returncode,'passed':ok})
    if not ok:print(text);raise SystemExit(1)
(ROOT/'Build/keil_results.json').write_text(json.dumps(results,indent=2))
