param(
    [ValidateRange(1,9)][int]$Lab = 9,
    [string]$Keil = 'D:\Keil5\UV4\UV4.exe'
)
$ErrorActionPreference = 'Stop'
$labRoot = Split-Path -Parent $PSScriptRoot
$labFolder = Get-ChildItem -LiteralPath (Join-Path $labRoot 'Labs') -Directory |
    Where-Object { $_.Name.StartsWith(('{0:D2}_' -f $Lab)) } | Select-Object -First 1
$labProject = Join-Path $labRoot 'MDK\F411_Labs.uvprojx'
$labLog = Join-Path $labRoot ('Build\flash_{0}.log' -f $labFolder.Name)
if (-not (Test-Path -LiteralPath $Keil)) { throw 'Keil UV4.exe not found. Set -Keil to its location.' }
$labArgs = '-f "{0}" -t "{1}" -o "{2}" -j0' -f $labProject,$labFolder.Name,$labLog
$labProcess = Start-Process -FilePath $Keil -ArgumentList $labArgs -WindowStyle Hidden -PassThru
$labProcess.WaitForExit()
$labOutput = Get-Content -LiteralPath $labLog -Raw
Write-Output $labOutput
if ($labOutput -notmatch 'Verify OK') { throw 'Flash verification did not succeed. Inspect the log.' }
