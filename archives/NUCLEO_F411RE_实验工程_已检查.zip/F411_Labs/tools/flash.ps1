param(
    [ValidateRange(1,9)][int]$Lab = 9,
    [string]$Keil = 'D:\Keil5\UV4\UV4.exe',
    [switch]$BuildOnly
)
$ErrorActionPreference = 'Stop'
$labRoot = Split-Path -Parent $PSScriptRoot
$labFolder = Get-ChildItem -LiteralPath (Join-Path $labRoot 'Labs') -Directory |
    Where-Object { $_.Name.StartsWith(('{0:D2}_' -f $Lab)) } | Select-Object -First 1
$labProject = Join-Path $labRoot 'MDK\F411_Labs.uvprojx'
if (-not $labFolder) { throw 'Selected lab directory was not found.' }
$labBuildDir = Join-Path $labRoot 'Build'
New-Item -ItemType Directory -Path $labBuildDir -Force | Out-Null
$labBuildLog = Join-Path $labBuildDir ('preflash_build_{0}.log' -f $labFolder.Name)
$labLog = Join-Path $labRoot ('Build\flash_{0}.log' -f $labFolder.Name)
if (-not (Test-Path -LiteralPath $Keil)) { throw 'Keil UV4.exe not found. Set -Keil to its location.' }
# A source change must be compiled successfully before a firmware can be flashed.
Set-Content -LiteralPath $labBuildLog -Value ''
$labBuildArgs = '-b "{0}" -t "{1}" -o "{2}" -j0' -f $labProject,$labFolder.Name,$labBuildLog
$labBuildProcess = Start-Process -FilePath $Keil -ArgumentList $labBuildArgs -WindowStyle Hidden -Wait -PassThru
$labBuildOutput = Get-Content -LiteralPath $labBuildLog -Raw
Write-Output $labBuildOutput
if ($labBuildProcess.ExitCode -notin @(0,1) -or $labBuildOutput -notmatch '\b0 Error\(s\)') {
    throw 'Build failed; flashing was not attempted.'
}
$labImage = Join-Path $labBuildDir ('Keil_{0}\{0}.axf' -f $labFolder.Name)
if (-not (Test-Path -LiteralPath $labImage)) { throw 'Compiled AXF is missing; flashing was not attempted.' }
if ($BuildOnly) { Write-Output 'BUILD ONLY: no hardware connection or flash write was performed.'; return }
# Clear old success text before launching this download.
Set-Content -LiteralPath $labLog -Value ''
$labArgs = '-f "{0}" -t "{1}" -o "{2}" -j0' -f $labProject,$labFolder.Name,$labLog
$labProcess = Start-Process -FilePath $Keil -ArgumentList $labArgs -WindowStyle Hidden -Wait -PassThru
$labOutput = Get-Content -LiteralPath $labLog -Raw
Write-Output $labOutput
if ($labProcess.ExitCode -ne 0 -or $labOutput -notmatch 'Verify OK') {
    throw 'Flash verification did not succeed. Inspect the log.'
}
