"""Fetch ST SPL 1.8.0 source from a pinned mirror; retain upstream licences."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import shutil
import urllib.request
import time

ROOT = Path(__file__).resolve().parents[1]
COMMIT = '413abc8af439fc11d21d22dfe7d77f8cb80ac177'
BASE = 'https://raw.githubusercontent.com/whimsicalraps/STM32F4xx_DSP_StdPeriph_Lib/' + COMMIT + '/'
paths = ['Libraries/CMSIS/Device/ST/STM32F4xx/Include/stm32f4xx.h',
         'Libraries/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h',
         'Libraries/CMSIS/Device/ST/STM32F4xx/Source/Templates/arm/startup_stm32f411xe.s',
         'Libraries/CMSIS/CMSIS_END_USER_LICENCE_AGREEMENT.rtf']
for name in ['gpio', 'rcc', 'syscfg', 'exti', 'usart']:
    for folder, suffix in [('inc', '.h'), ('src', '.c')]:
        paths.append(f'Libraries/STM32F4xx_StdPeriph_Driver/{folder}/stm32f4xx_{name}{suffix}')
for folder, suffix in [('inc', '.h'), ('src', '.c')]:
    paths.append(f'Libraries/STM32F4xx_StdPeriph_Driver/{folder}/misc{suffix}')

def download(url):
    for attempt in range(3):
        try:
            return urllib.request.urlopen(url, timeout=45).read()
        except Exception:
            if attempt == 2: raise
            time.sleep(1)

def fetch(path):
    url = BASE + path
    dst = ROOT / 'Vendor' / path
    data = dst.read_bytes() if dst.exists() else download(url)
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(data)
    return {'path': str(dst.relative_to(ROOT)), 'url': url,
            'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
    records = list(pool.map(fetch, paths))
# CMSIS 5 supports AC6 and retains NVIC->IP required by the legacy ST SPL.
dst = ROOT / 'Vendor' / 'CMSIS_Core'
dst.mkdir(exist_ok=True)
for name in ['core_cm4.h', 'cmsis_compiler.h', 'cmsis_armclang.h', 'cmsis_armcc.h',
             'cmsis_gcc.h', 'cmsis_version.h', 'mpu_armv7.h']:
    url = 'https://raw.githubusercontent.com/ARM-software/CMSIS_5/5.9.0/CMSIS/Core/Include/' + name
    data = download(url)
    (dst/name).write_bytes(data)
    records.append({'path':str((dst/name).relative_to(ROOT)), 'url':url,
                    'sha256':hashlib.sha256(data).hexdigest(), 'bytes':len(data)})
data=download('https://raw.githubusercontent.com/ARM-software/CMSIS_5/5.9.0/LICENSE.txt')
(dst/'LICENSE.txt').write_bytes(data)
(ROOT / 'Vendor' / 'manifest.json').write_text(json.dumps(records, indent=2), encoding='utf-8')
print('Fetched', len(records), 'ST SPL / CMSIS 5.9 source files.')
