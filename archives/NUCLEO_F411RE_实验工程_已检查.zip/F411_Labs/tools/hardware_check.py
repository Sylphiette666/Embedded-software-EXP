"""Bench checks: serial replies + actual GPIO registers; no simulated button claims."""
import argparse
import json
from pathlib import Path
import shutil
import os
import time
import serial
from pyocd.core.helpers import ConnectHelper
from pyocd.flash.file_programmer import FileProgrammer
from pyocd.core.target import Target

ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser()
p.add_argument('--lab',type=int,required=True,choices=[1,2,3,6,7,9])
p.add_argument('--port',default='COM3')
p.add_argument('--drive',default='E:/')
p.add_argument('--pack',default=r'D:\Work\嵌入式实验\.lab_downloads\Keil.STM32F4xx_DFP.2.17.1.pack')
args=p.parse_args()
lab=next(x for x in (ROOT/'Labs').iterdir() if x.name.startswith(f'{args.lab:02d}_'))
fw=ROOT/'Build'/lab.name/(lab.name+'.bin')
options={'pack':args.pack,'frequency':500000,'connect_mode':'attach',
         'pack.debug_sequences.enable':False}
results={'lab':lab.name,'timestamp':time.strftime('%Y-%m-%d %H:%M:%S'),'checks':[]}
with ConnectHelper.session_with_chosen_probe(unique_id='066FFF545150898367065349',
        target_override='stm32f411retx',options=options) as session:
    target=session.target
    target.halt()
    time.sleep(0.1)
    # Stop the old firmware's SysTick and IRQs before running the RAM flash algorithm.
    target.write32(0xE000E010,0)
    for i in range(8):
        target.write32(0xE000E180+i*4,0xFFFFFFFF)
        target.write32(0xE000E280+i*4,0xFFFFFFFF)
    target.write32(0xE000ED04,(1<<25)|(1<<27))
    FileProgrammer(session,chip_erase='sector').program(str(fw.with_suffix('.hex')))
    # Verify the actual flash contents after programming.
    binary=fw.read_bytes()
    assert bytes(target.read_memory_block8(0x08000000,len(binary)))==binary,'Flash verify failed'
    results['flash_readback_verified']=True
    with serial.Serial(args.port,115200,timeout=0.15) as port:
        time.sleep(0.3)  # Allow the Windows VCP to apply its line coding.
        port.reset_input_buffer()
        target.reset(Target.ResetType.SYSRESETREQ)
        time.sleep(0.1)
        target.resume()
        time.sleep(0.25)
        boot=port.read(4096).decode('utf-8',errors='replace')
        results['boot']=boot
        print(boot)
        assert 'NUCLEO-F411RE' in boot,'No startup banner'
        if args.lab in [6,9]:
            for command,expected in [('Y',1),('N',0),('X',0),('Y',1),('N',0)]:
                port.reset_input_buffer();port.write(command.encode());time.sleep(0.03)
                reply=port.read(4096).decode('utf-8',errors='replace')
                odr=(target.read32(0x40020014)>>5)&1
                idr=(target.read32(0x40020010)>>5)&1
                check={'command':command,'reply':reply,'PA5_ODR':odr,'PA5_IDR':idr,'expected':expected}
                assert odr==expected and idr==expected,check
                if command!='X':assert 'OK '+command in reply,check
                results['checks'].append(check);print(check)
        if args.lab==9:
            port.write(b'M');time.sleep(0.03)
            text=port.read(4096).decode('utf-8')
            assert '\u5d4c\u5165\u5f0f\u5b9e\u9a8c\u5b8c\u6210\u5566' in text,text
            results['checks'].append({'command':'M','reply':text})
            port.write(b'B');time.sleep(0.03)
            print(port.read(4096).decode('utf-8'))
        if args.lab in [1,2,3,7,9]:
            edges=[];samples=[];last=None;start=time.perf_counter()
            while time.perf_counter()-start<4.3:
                odr=target.read32(0x40020014)
                state=((odr>>5)&1,(odr>>6)&1)
                if args.lab==2:assert state in [(1,0),(0,1)],state
                if state[0]!=last:
                    edges.append(time.perf_counter()-start);samples.append(state)
                    last=state[0]
                time.sleep(0.01)
            intervals=[b-a for a,b in zip(edges[1:],edges[2:])]
            expected=0.5 if args.lab in [1,2] else 1.0
            assert len(intervals)>=2,edges
            assert all(abs(x-expected)<0.08 for x in intervals),intervals
            results['checks'].append({'edge_times_seconds':edges,'intervals_seconds':intervals,
                'states':samples,'expected_interval_seconds':expected,
                'method':'Host-timed SWD GPIO sampling; not oscilloscope timing accuracy.'})
            print('Measured edge intervals:',intervals)
        if args.lab==9:
            port.write(b'N?');time.sleep(0.03)
            results['final_state']=port.read(4096).decode('utf-8')
        if args.lab==7:
            results['systick_load']=target.read32(0xE000E014)
            assert results['systick_load']==15999
            results['serial_trace']=port.read(4096).decode('utf-8',errors='replace')
        # Debug flags should not keep a halted CPU after disconnect.
        target.resume()
dest=ROOT/'Build'/('hardware_'+lab.name+'.json')
dest.write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print('PASS',lab.name)
