"""Run compiled Keil ARM code with modelled GPIO/UART and an injected ms clock.

Requires unicorn==2.1.4 and pyelftools. This is a software regression test,
not a board/peripheral acceptance test. No probe, COM port or flash is touched.
"""
from pathlib import Path
import hashlib
import json
import struct
import time
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_THUMB, UC_MODE_MCLASS, UC_HOOK_CODE
from unicorn.arm_const import UC_ARM_REG_SP, UC_ARM_REG_LR, UC_ARM_REG_PC, UC_ARM_REG_R0
from elftools.elf.elffile import ELFFile

ROOT=Path(__file__).resolve().parents[1]
GPIOA=0x40020000
GPIOC=0x40020800
EXTI=0x40013C00
USART=0x40004400
STOP=0x0807F000
MASK=0xFFFFFFFF
results=[]

class Machine:
    def __init__(self,number):
        self.lab=next(p for p in (ROOT/'Labs').iterdir() if p.name.startswith(f'{number:02}_'))
        self.axf=ROOT/'Build'/('Keil_'+self.lab.name)/(self.lab.name+'.axf')
        self.uc=Uc(UC_ARCH_ARM,UC_MODE_THUMB|UC_MODE_MCLASS)
        for base,size in [(0x08000000,0x80000),(0x20000000,0x20000),(0xE000E000,0x2000)]:
            self.uc.mem_map(base,size)
        self.peripherals=bytearray(0x30000)
        self.uc.mmio_map(0x40000000,0x30000,self.mmio_read,None,self.mmio_write,None)
        with self.axf.open('rb') as f:
            elf=ELFFile(f)
            self.symbols={s.name:s['st_value'] for s in elf.get_section_by_name('.symtab').iter_symbols()}
            for section in elf.iter_sections():
                if section['sh_flags'] & 2 and section['sh_type']!='SHT_NOBITS' and section['sh_size']:
                    self.uc.mem_write(section['sh_addr'],section.data())
        self.tx=bytearray()
        self.edges=[]
        self.ms=0
        self.block_budget=None
        boundary={1:'Time_Now',2:'Delay_Ms',3:'Delay_Ms',4:'Keys_Poll',
                  5:'Keys_PollIRQ',6:'UART_GetChar',7:'Time_Now',
                  8:'Keys_PollIRQ',9:'Keys_PollIRQ'}[number]
        self.boundary=self.symbols[boundary]&~1
        self.w32(GPIOA+0x10,1)
        self.w32(GPIOC+0x10,1<<13)
        self.w32(USART,0x80)  # TXE; no receive byte pending.
        self.uc.hook_add(UC_HOOK_CODE,self.on_block,begin=self.boundary,end=self.boundary+1)
        self.uc.reg_write(UC_ARM_REG_SP,0x2001FFF0)
        self.uc.reg_write(UC_ARM_REG_LR,STOP|1)
        self.pc=self.symbols['main']|1
        self.run_slice(1000)

    def r32(self,addr):
        if 0x40000000<=addr<0x40030000:
            offset=addr-0x40000000
            return int.from_bytes(self.peripherals[offset:offset+4],'little')
        return struct.unpack('<I',self.uc.mem_read(addr,4))[0]
    def w32(self,addr,value):
        data=struct.pack('<I',value&MASK)
        if 0x40000000<=addr<0x40030000:
            offset=addr-0x40000000
            self.peripherals[offset:offset+4]=data
        else:self.uc.mem_write(addr,data)
    def variable(self,name):return self.r32(self.symbols[name])
    def mmio_read(self,uc,offset,size,user):
        return int.from_bytes(self.peripherals[offset:offset+size],'little')
    def mmio_write(self,uc,offset,size,value,user):
        addr=0x40000000+offset
        self.peripherals[offset:offset+size]=value.to_bytes(size,'little')
        if addr in (GPIOA+0x18,GPIOA+0x1A):
            old=self.r32(GPIOA+0x14)
            if addr==GPIOA+0x1A:
                new=old & ~(value&0xFFFF)
            else:
                # F4 BSRR set wins if both set/reset bits are specified.
                new=(old & ~((value>>16)&0xFFFF)) | (value&0xFFFF)
            self.w32(GPIOA+0x14,new)
            self.w32(GPIOA+0x10,(self.r32(GPIOA+0x10)&~0x60)|(new&0x60))
            if (old^new)&0x60:self.edges.append((self.ms,(new>>5)&3))
        elif addr==USART+4:
            self.tx.append(value&0xFF)
        elif addr==EXTI+0x14:
            self.w32(addr,0) # Clear the injected pending bit.

    def on_block(self,uc,addr,size,user):
        if self.block_budget is not None:
            if self.block_budget==0:
                uc.emu_stop()
            else:
                self.block_budget-=1

    def run_slice(self,count=2500):
        # Resume only at a function entry, never in a Thumb IT block or a partial
        # emulated basic block. This also keeps input injection deterministic.
        self.block_budget=max(1,count//100)
        if self.pc != self.boundary:self.block_budget=0
        self.uc.emu_start(self.pc|1,STOP,count=1000000)
        self.block_budget=None
        self.pc=self.uc.reg_read(UC_ARM_REG_PC)
        assert self.pc==self.boundary, 'Did not reach the main-loop boundary'

    def call(self,name,arg=0):
        context=self.uc.context_save()
        self.uc.reg_write(UC_ARM_REG_SP,0x2001F000)
        self.uc.reg_write(UC_ARM_REG_LR,STOP|1)
        self.uc.reg_write(UC_ARM_REG_R0,arg)
        self.uc.emu_start(self.symbols[name]|1,STOP,count=100000)
        assert self.uc.reg_read(UC_ARM_REG_PC)==STOP, 'Function did not return: '+name
        value=self.uc.reg_read(UC_ARM_REG_R0)
        self.uc.context_restore(context)
        return value

    def advance(self,milliseconds):
        for _ in range(milliseconds):
            self.ms=(self.ms+1)&MASK
            self.w32(self.symbols['g_millis'],self.ms)
            self.run_slice()

    def set_time(self,ms):
        self.ms=ms&MASK
        self.w32(self.symbols['g_millis'],self.ms)

    def keys(self,b1=False,pa0=False,interrupts=True):
        for addr,bit,down,line,handler in [
            (GPIOC+0x10,13,b1,13,'EXTI15_10_IRQHandler'),
            (GPIOA+0x10,0,pa0,0,'EXTI0_IRQHandler')]:
            old=self.r32(addr)
            self.w32(addr,old&~(1<<bit) if down else old|(1<<bit))
            if down and (old&(1<<bit)) and interrupts and (self.r32(EXTI)&(1<<line)):
                self.w32(EXTI+0x14,self.r32(EXTI+0x14)|(1<<line))
                self.call(handler)
                self.w32(EXTI+0x14,0)
        self.run_slice()

    def press(self,b1=False,pa0=False):
        self.keys(b1,pa0);self.advance(30)
        self.keys();self.advance(30)

    def receive(self,data,run=True):
        for value in data:
            self.w32(USART+4,value);self.w32(USART,0xA0)
            self.call('USART2_IRQHandler')
            self.w32(USART,0x80)
            if run:self.run_slice()

    @property
    def leds(self):return (self.r32(GPIOA+0x14)>>5)&3
    @property
    def text(self):return self.tx.decode('utf-8')

def check(name,function):
    start=time.perf_counter()
    function()
    results.append({'test':name,'passed':True,'seconds':round(time.perf_counter()-start,3)})
    print('PASS',name,flush=True)

def initialization():
    m=Machine(8)
    assert m.variable('SystemCoreClock')==16000000
    assert m.r32(0xE000E014)==15999
    assert m.r32(0xE000E010)&7==7
    assert (m.r32(GPIOA)>>10)&15==5
    assert (m.r32(GPIOA)>>4)&15==10 # PA2/3 alternate mode
    assert (m.r32(GPIOA+0x20)>>8)&255==0x77
    assert m.r32(GPIOA+0x0C)&3==1
    assert (m.r32(GPIOC+0x0C)>>26)&3==1
    assert m.r32(EXTI)&0x2001==0x2001
    assert m.r32(EXTI+0x0C)&0x2001==0x2001
    assert (m.r32(0x40013814)>>4)&15==2 # SYSCFG EXTICR4 EXTI13 = C
    assert m.r32(0x40013808)&15==0 # EXTI0 = A
    assert m.r32(USART+8)==139
    assert (m.r32(USART+0x0C)&((1<<13)|(1<<5)|12))==((1<<13)|(1<<5)|12)
    assert 'LAB 8' in m.text and m.leds==0
    m.set_time(0xFFFFFFFF);m.call('SysTick_Handler')
    assert m.variable('g_millis')==0

def polling():
    m=Machine(4)
    m.keys(True);m.advance(5);m.keys();m.advance(5)
    m.keys(True);m.advance(19);assert m.leds==0
    m.advance(1);assert m.leds==3
    state_lines=m.text.count('STATE ')
    m.advance(500);assert m.leds==3 and m.text.count('STATE ')==state_lines
    m.keys();m.advance(20);m.press(True);assert m.leds==0
    m.press(pa0=True);assert m.leds==1
    m.press(pa0=True);assert m.leds==2
    m.press(True);assert m.leds==1
    m=Machine(4);m.press(True,True);assert m.leds==1

def rollover():
    for number in (4,5):
        m=Machine(number);m.set_time(0xFFFFFFF5)
        m.keys(pa0=True);m.advance(19);assert m.leds==0
        m.advance(1);assert m.leds==(1 if number==4 else 2)
        m.keys();m.advance(30);m.press(pa0=True)
        assert m.leds==(2 if number==4 else 0)

def interrupts():
    m=Machine(5)
    m.press(True);assert m.leds==1
    m.press(pa0=True);assert m.leds==3
    m.press(True);assert m.leds==2
    m.press(pa0=True);assert m.leds==0
    m.keys(True,True);m.advance(30);assert m.leds==3
    m.advance(500);assert m.leds==3
    m=Machine(5)
    # A sampled low level without an injected IRQ must not trigger the IRQ application.
    m.keys(pa0=True,interrupts=False);m.advance(30);assert m.leds==0
    m.keys();m.advance(30);m.press(pa0=True);assert m.leds==2
    m=Machine(5)
    for _ in range(4):
        m.keys(pa0=True);m.advance(2);m.keys();m.advance(2)
    assert m.leds==0
    m.keys(pa0=True);m.advance(20);assert m.leds==2
    assert m.variable('g_key1_irq_count')==5
    assert m.text.count('STATE ')==1

def serial():
    m=Machine(6)
    for char,expected in [(b'Y',1),(b'N',0),(b'X',0),(b'Y',1),(b'N',0),(b'y',0),(b'\r\n',0)]:
        m.receive(char);assert m.leds==expected
    m.receive(b'?');assert 'STATE ' in m.text and m.variable('g_uart_overruns')==0
    # Exercise actual RX ring wrap and recovery after full buffer.
    for _ in range(140):m.receive(b'YN')
    assert m.leds==0 and m.variable('g_uart_overruns')==0
    m.receive(b'X'*128,run=False)
    assert m.variable('g_uart_overruns')==1
    m.run_slice(50000);m.receive(b'Y');assert m.leds==1

def integrated():
    m=Machine(8);phrase='嵌入式实验完成啦'
    m.press(pa0=True);assert m.text.count(phrase)==1 and m.leds==0
    m.press(True);assert 'BLINK ON' in m.text and m.leds==1
    m.advance(1050);assert m.leds==0
    m.keys(pa0=True);m.advance(30);assert m.text.count(phrase)==2
    m.advance(1050);assert m.text.count(phrase)==2 and m.leds==1
    m.keys();m.advance(30);m.press(True);assert 'BLINK OFF' in m.text and m.leds==0
    m.advance(1100);assert m.leds==0
    m.press(pa0=True);assert m.text.count(phrase)==3
    # Restart timing near uint32 wrap: enabling starts a fresh schedule.
    m.set_time(0xFFFFFF00);m.press(True);assert m.leds==1
    m.advance(1050);assert m.leds==0

def periodic():
    for number,interval in [(1,500),(7,1000)]:
        m=Machine(number);m.advance(interval*3+100)
        edges=m.edges
        assert len(edges)>=3,(number,edges)
        for a,b in zip(edges,edges[1:]):
            assert abs(b[0]-a[0]-interval)<=1,(number,edges)
    # Labs 2/3 use a blocking delay: inspect their initialized outputs here.
    # Their wall-clock blinking was checked separately on the real board.
    assert Machine(2).leds==1
    assert Machine(3).leds==1

def demonstration():
    m=Machine(9);phrase='嵌入式实验完成啦'
    m.press(True);assert m.leds==1 and 'BLINK ON' in m.text
    m.keys(True);m.advance(850);assert m.text.count(phrase)==1
    m.keys();m.advance(30);assert m.text.count('BLINK ON')==1 and 'BLINK OFF' not in m.text
    m.receive(b'N');assert m.leds==0
    m.receive(b'Y');assert m.leds==1

if __name__=='__main__':
    (ROOT/'Build/logic_check_results.json').unlink(missing_ok=True)
    for name,fn in [('register_initialization_and_systick_wrap',initialization),
                    ('polling_bounce_hold_mutual_exclusion_and_simultaneous_keys',polling),
                    ('debounce_uint32_rollover',rollover),('two_exti_inputs_and_bounce',interrupts),
                    ('uart_commands_ring_wrap_and_overflow_recovery',serial),
                    ('lab8_chinese_while_blinking_stop_and_rollover',integrated),
                    ('periodic_outputs_labs_1_7_and_initial_outputs_2_3',periodic),
                    ('board_only_short_and_long_press',demonstration)]:
        check(name,fn)
    images={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((ROOT/'Build').glob('Keil_*/*.axf'))}
    out={'method':'Unicorn executes actual Keil AXF; GPIO/UART modelled; time and IRQ entry injected.',
         'physical_hardware_test':False,'checked_at':time.strftime('%Y-%m-%d %H:%M:%S'),
         'tests':results,'images_sha256':images}
    (ROOT/'Build/logic_check_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print('ALL SOFTWARE CHECKS PASSED')
