param([string]$Port = 'COM3')
$ErrorActionPreference = 'Stop'
$labSerial = New-Object System.IO.Ports.SerialPort $Port,115200,None,8,One
$labSerial.Encoding = New-Object System.Text.UTF8Encoding $false
$labSerial.Handshake = [System.IO.Ports.Handshake]::None
$labSerial.DtrEnable = $true
$labSerial.ReadTimeout = 100
try {
    $labSerial.Open()
    Write-Host "$Port 115200 8N1 UTF-8. Y/N = LED, B = blink, M = message, ? = state; Esc = close."
    while ($true) {
        if ($labSerial.BytesToRead -gt 0) { Write-Host -NoNewline $labSerial.ReadExisting() }
        if ([Console]::KeyAvailable) {
            $labKey = [Console]::ReadKey($true)
            if ($labKey.Key -eq [ConsoleKey]::Escape) { break }
            if ($labKey.KeyChar -ne [char]0) { $labSerial.Write($labKey.KeyChar.ToString()) }
        }
        Start-Sleep -Milliseconds 20
    }
} finally {
    if ($labSerial.IsOpen) { $labSerial.Close() }
    $labSerial.Dispose()
}
