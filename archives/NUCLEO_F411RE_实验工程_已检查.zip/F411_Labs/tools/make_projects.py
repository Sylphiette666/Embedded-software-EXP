"""Create a Keil multi-target project from the vendor's AC6 XML schema."""
from pathlib import Path
from copy import deepcopy
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
tree=ET.parse(ROOT/'tools/vendor_project_template.uvprojx')
root=tree.getroot()
template=deepcopy(root.find('./Targets/Target'))
root.find('Targets').clear()
for node in list(root):
    if node.tag not in ['SchemaVersion','Header','Targets']:root.remove(node)
def set_value(node,path,value):
    leaf=node.find(path)
    if leaf is None:
        parts=path.split('/'); parent=node
        for part in parts:
            child=parent.find(part)
            if child is None:child=ET.SubElement(parent,part)
            parent=child
        leaf=parent
    leaf.text=str(value)
for lab in sorted((ROOT/'Labs').iterdir()):
    if not lab.is_dir():continue
    t=deepcopy(template)
    set_value(t,'TargetName',lab.name)
    set_value(t,'pCCUsed','6240000::V6.24::ARMCLANG')
    set_value(t,'uAC6','1')
    base='TargetOption/TargetCommonOption/'
    values={
      'Device':'STM32F411RETx','Vendor':'STMicroelectronics',
      'PackID':'Keil.STM32F4xx_DFP.2.17.1',
      'Cpu':'IROM(0x08000000,0x80000) IRAM(0x20000000,0x20000) CPUTYPE("Cortex-M4") FPU2 CLOCK(16000000) ELITTLE',
      'RegisterFile':'', 'SFDFile':'$$Device:STM32F411RETx$CMSIS\\SVD\\STM32F411.svd',
      'FlashDriverDll':'UL2CM3(-S0 -C0 -P0 -FD20000000 -FC1000 -FN1 -FF0STM32F4xx_512 -FS08000000 -FL080000 -FP0($$Device:STM32F411RETx$CMSIS\\Flash\\STM32F4xx_512.FLM))',
      'OutputDirectory':'..\\Build\\Keil_'+lab.name+'\\',
      'OutputName':lab.name,'ListingPath':'..\\Build\\Keil_'+lab.name+'\\',
      'CreateHexFile':'1','CreateExecutable':'1','DebugInformation':'1',
      'TargetStatus/InvalidFlash':'0'}
    for k,v in values.items():set_value(t,base+k,v)
    a='TargetOption/TargetArmAds/'
    for k,v in {'ArmAdsMisc/mOS':'0','ArmAdsMisc/hadIRAM2':'0','ArmAdsMisc/useUlib':'1',
                'ArmAdsMisc/OnChipMemories/IROM/Size':'0x80000',
                'ArmAdsMisc/OnChipMemories/OCR_RVCT4/Size':'0x80000',
                'ArmAdsMisc/OnChipMemories/OCR_RVCT5/Size':'0x20000',
                'Cads/VariousControls/Define':'STM32F411xE,USE_STDPERIPH_DRIVER',
                'Cads/VariousControls/MiscControls':'-Wall -Wextra',
                'Cads/VariousControls/IncludePath':'..\\App;..\\Vendor\\CMSIS_Core;..\\Vendor\\Libraries\\CMSIS\\Device\\ST\\STM32F4xx\\Include;..\\Vendor\\Libraries\\STM32F4xx_StdPeriph_Driver\\inc',
                'Aads/ClangAsOpt':'0','Aads/VariousControls/Define':'__MICROLIB',
                'LDads/umfTarg':'0','LDads/useFile':'1','LDads/ScatterFile':'.\\flash.sct',
                'LDads/Misc':'--entry=Reset_Handler'}.items():set_value(t,a+k,v)
    set_value(t,'TargetOption/Utilities/Flash2','STLink\\ST-LINKIII-KEIL_SWO.dll')
    for k,v in {'UseSimulator':'0','UseTarget':'1','LoadApplicationAtStartup':'1',
                'RunToMain':'1','TargetSelection':'6'}.items():
        set_value(t,'TargetOption/DebugOption/'+k,v)
    groups=t.find('Groups');groups.clear()
    contents={
      'Experiments':sorted((ROOT/'Labs').glob('*/main.c')),
      'Board drivers':[ROOT/'App/platform.c',ROOT/'App/system_lab.c',ROOT/'App/platform.h',ROOT/'App/stm32f4xx_conf.h'],
      'STM32 Standard Peripheral Library':sorted((ROOT/'Vendor/Libraries/STM32F4xx_StdPeriph_Driver/src').glob('*.c')),
      'Startup':[ROOT/'Vendor/Libraries/CMSIS/Device/ST/STM32F4xx/Source/Templates/arm/startup_stm32f411xe.s']}
    for name,files in contents.items():
        group=ET.SubElement(groups,'Group');ET.SubElement(group,'GroupName').text=name
        parent=ET.SubElement(group,'Files')
        for file in files:
            f=ET.SubElement(parent,'File')
            ET.SubElement(f,'FileName').text=file.name
            ET.SubElement(f,'FileType').text='2' if file.suffix=='.s' else ('5' if file.suffix=='.h' else '1')
            ET.SubElement(f,'FilePath').text='..\\'+str(file.relative_to(ROOT)).replace('/','\\')
            if name == 'Experiments':
                opt=ET.SubElement(f,'FileOption')
                prop=deepcopy(template.find('TargetOption/CommonProperty'))
                prop.find('IncludeInBuild').text='1' if file.parent == lab else '0'
                opt.append(prop)
    root.find('Targets').append(t)
ET.indent(tree,space='  ')
tree.write(ROOT/'MDK/F411_Labs.uvprojx',encoding='utf-8',xml_declaration=True)
print('Generated nine Keil targets.')

# Debugger selection lives in uvoptx as well as the project file.
import re
debug_tree=ET.parse(ROOT/'tools/vendor_debug_template.uvoptx')
debug_root=debug_tree.getroot()
debug_template=deepcopy(debug_root.find('Target'))
for node in list(debug_root):
    if node.tag not in ['SchemaVersion','Header','Extensions']:debug_root.remove(node)
for lab in sorted((ROOT/'Labs').iterdir()):
    if not lab.is_dir():continue
    t=deepcopy(debug_template)
    set_value(t,'TargetName',lab.name)
    for path,value in {'CLKADS':'16000000','OPTTT/RunSim':'0','OPTTT/RunTarget':'1',
        'OPTTT/BeepAtEnd':'0','OPTFL/IsCurrentTarget':'1' if lab.name.startswith('09_') else '0',
        'OPTLEX/ListingPath':'..\\Build\\Keil_'+lab.name+'\\',
        'DebugOpt/bEvRecOn':'0','DebugOpt/nTsel':'6',
        'DebugDescription/DbgClock':'1000000'}.items():set_value(t,'TargetOption/'+path,value)
    opt=t.find('TargetOption')
    for n in list(opt):
        if n.tag in ['ScvdPack','Breakpoint','WatchWindow1','WatchWindow2','MemoryWindow1','MemoryWindow2']:
            opt.remove(n)
    reg=opt.find('TargetDriverDllRegistry')
    for entry in list(reg):
        if entry.findtext('Key') not in ['ST-LINKIII-KEIL_SWO','ST-LINKIII-KEIL','UL2CM3']:
            reg.remove(entry);continue
        n=entry.find('Name')
        value=n.text or ''
        value=re.sub(r'-U\S+\s*','',value)
        value=value.replace('-SF10000','-SF1000').replace('-TC84000000','-TC16000000')
        value=value.replace('STM32F4xx_256','STM32F4xx_512').replace('-FL040000','-FL080000')
        value=value.replace('STM32F401VCTx','STM32F411RETx')
        n.text=value
    debug_root.append(t)
ET.indent(debug_tree,space='  ')
debug_tree.write(ROOT/'MDK/F411_Labs.uvoptx',encoding='utf-8',xml_declaration=True)
print('Configured ST-Link SWD and 512 KB Flash for all targets.')
