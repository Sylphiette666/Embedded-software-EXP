"""Build all nine firmware images with the locally installed Arm Compiler 6."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--compiler', default=r'D:\Keil5\ARM\ARMCLANG\bin')
parser.add_argument('--lab', type=int, choices=range(1, 10))
args = parser.parse_args()
BIN = Path(args.compiler)
OUT = ROOT / 'Build'
OUT.mkdir(exist_ok=True)
INC = [ROOT/'App', ROOT/'Vendor/CMSIS_Core',
       ROOT/'Vendor/Libraries/CMSIS/Device/ST/STM32F4xx/Include',
       ROOT/'Vendor/Libraries/STM32F4xx_StdPeriph_Driver/inc']
sources = [ROOT/'App/system_lab.c', ROOT/'App/platform.c'] + sorted(
    (ROOT/'Vendor/Libraries/STM32F4xx_StdPeriph_Driver/src').glob('*.c'))
flags = ['--target=arm-arm-none-eabi', '-mcpu=cortex-m4', '-mfpu=fpv4-sp-d16',
         '-mfloat-abi=hard', '-std=c11', '-O1', '-g', '-fshort-enums', '-fshort-wchar',
         '-ffunction-sections', '-fdata-sections', '-Wall', '-Wextra',
         '-DSTM32F411xE', '-DUSE_STDPERIPH_DRIVER', '-D__MICROLIB']
flags += ['-I'+str(p) for p in INC]
log = []
def run(command):
    result = subprocess.run([str(x) for x in command], cwd=ROOT,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors='replace')
    log.append(' '.join(str(x) for x in command)+'\n'+result.stdout)
    if result.stdout: print(result.stdout, end='')
    if result.returncode:
        (OUT/'build.log').write_text('\n'.join(log), encoding='utf-8')
        raise SystemExit(result.returncode)

common = OUT/'Common'; common.mkdir(exist_ok=True)
objects = []
for src in sources:
    obj = common/(src.stem+'.o')
    run([BIN/'armclang.exe', *flags, '-c', src, '-o', obj]); objects.append(obj)
startup = ROOT/'Vendor/Libraries/CMSIS/Device/ST/STM32F4xx/Source/Templates/arm/startup_stm32f411xe.s'
obj = common/'startup_stm32f411xe.o'
run([BIN/'armasm.exe', '--cpu=Cortex-M4.fp.sp', '--apcs=interwork', '-g',
     '--pd', '__MICROLIB SETA 1', startup, '-o', obj]); objects.append(obj)
results = []
for lab in sorted((ROOT/'Labs').iterdir()):
    if not lab.is_dir() or (args.lab and int(lab.name[:2]) != args.lab): continue
    folder = OUT/lab.name; folder.mkdir(exist_ok=True)
    main = folder/'main.o'
    run([BIN/'armclang.exe', *flags, '-c', lab/'main.c', '-o', main])
    axf = folder/(lab.name+'.axf')
    run([BIN/'armlink.exe', '--cpu=Cortex-M4.fp.sp', '--library_type=microlib',
         '--strict', '--scatter='+str(ROOT/'MDK/flash.sct'), '--entry=Reset_Handler',
         '--map', '--info=sizes', '--list='+str(folder/'link.map'),
         '-o', axf, *objects, main])
    run([BIN/'fromelf.exe', '--i32combined', '--output='+str(folder/(lab.name+'.hex')), axf])
    run([BIN/'fromelf.exe', '--bin', '--output='+str(folder/(lab.name+'.bin')), axf])
    results.append({'lab':lab.name, 'binary_bytes':(folder/(lab.name+'.bin')).stat().st_size})
    print('BUILT', lab.name)
(OUT/'build.log').write_text('\n'.join(log), encoding='utf-8')
(OUT/'build_results.json').write_text(json.dumps({'compiler':str(BIN),
    'built_at':time.strftime('%Y-%m-%d %H:%M:%S'), 'results':results}, indent=2), encoding='utf-8')
print('SUCCESS:', len(results), 'targets')
