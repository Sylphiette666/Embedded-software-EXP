/* Lab 2: LED GPIO init/control use registers, not GPIO library calls. */
#include "platform.h"
#define GPIOA_BSRR32 (*((volatile uint32_t *)(GPIOA_BASE + 0x18u)))
static void Register_LED_Init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    (void)RCC->AHB1ENR;
    /* SPL 1.8 exposes the 32-bit BSRR as two 16-bit halves. */
    GPIOA->BSRRH = (1u << 5) | (1u << 6);
    GPIOA->MODER = (GPIOA->MODER & ~((3u << 10) | (3u << 12))) |
                    (1u << 10) | (1u << 12);
    GPIOA->OTYPER &= ~((1u << 5) | (1u << 6));
    GPIOA->OSPEEDR &= ~((3u << 10) | (3u << 12));
    GPIOA->PUPDR &= ~((3u << 10) | (3u << 12));
}
int main(void)
{
    Time_Init(); Register_LED_Init(); UART_Init();
    Print_Banner(2, "Register-driven alternating LEDs");
    UART_Puts("PA6 needs an external LED for full visual acceptance.\r\n");
    while (1) {
        GPIOA_BSRR32 = (1u << 5) | (1u << (6 + 16));
        UART_Puts("LED0=1 LED1=0\r\n"); Delay_Ms(500);
        GPIOA_BSRR32 = (1u << 6) | (1u << (5 + 16));
        UART_Puts("LED0=0 LED1=1\r\n"); Delay_Ms(500);
    }
}
