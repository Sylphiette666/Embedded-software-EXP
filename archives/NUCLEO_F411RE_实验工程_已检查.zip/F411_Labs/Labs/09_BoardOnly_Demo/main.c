/* Optional demonstration for a bare board. NOT the original two-key task. */
#include "platform.h"
int main(void)
{
    Time_Init(); LED_Init(); Keys_Init(); UART_Init();
    Keys_EnableEXTI(KEY0_EVENT);
    Print_Banner(9, "BOARD-ONLY demonstration (not two-key acceptance)");
    UART_Puts("B1 short press: blink on/off; hold >=800 ms: Chinese message.\r\n"
              "Y/N: steady on/off; B: blink toggle; M: message; ?: state.\r\n");
    uint8_t blink = 0u, tracking = 0u, long_sent = 0u;
    uint8_t release_wait = 0u;
    uint32_t last = Time_Now(), pressed_at = 0u, release_at = 0u;
    while (1) {
        uint32_t now = Time_Now();
        uint8_t events = Keys_PollIRQ();
        uint8_t toggle = 0u;
        if (events & KEY0_EVENT) {
            tracking = 1u; pressed_at = now; long_sent = 0u; release_wait = 0u;
        }
        if (tracking) {
            if (Key_IsDown(0)) {
                release_wait = 0u;
                if (!long_sent && (uint32_t)(now - pressed_at) >= 800u) {
                    Print_Completed(); long_sent = 1u;
                }
            } else {
                if (!release_wait) { release_wait = 1u; release_at = now; }
                if ((uint32_t)(now - release_at) >= 20u) {
                    if (!long_sent) { toggle = 1u; }
                    tracking = 0u; release_wait = 0u;
                }
            }
        }
        int c = UART_GetChar();
        if (c == 'B') { toggle = 1u; }
        if (c == 'Y' || c == 'N') {
            blink = 0u; LED_Write(0, c == 'Y');
            UART_Puts(c == 'Y' ? "OK Y LED0=1\r\n" : "OK N LED0=0\r\n");
        }
        if (c == 'M') { Print_Completed(); }
        if (toggle) {
            blink ^= 1u; last = now; LED_Write(0, blink);
            UART_Puts(blink ? "BLINK ON\r\n" : "BLINK OFF\r\n");
        }
        if (blink && (uint32_t)(now - last) >= 1000u) {
            last += 1000u; LED_Toggle(0);
        }
        if (c == '?') { Print_State(); }
    }
}
