/* Deterministic 16 MHz HSI clock; no assumption about board HSE jumpers. */
#include "stm32f4xx.h"
uint32_t SystemCoreClock = 16000000u;
void SystemInit(void)
{
    SCB->CPACR |= (0xFu << 20); /* Cortex-M4 FPU CP10/CP11. */
    RCC->CR |= RCC_CR_HSION;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0u) {}
    RCC->CFGR = 0u; /* HSI, AHB /1, APB1 /1, APB2 /1. */
    while ((RCC->CFGR & RCC_CFGR_SWS) != 0u) {}
    RCC->CR &= ~(RCC_CR_PLLON | RCC_CR_HSEON | RCC_CR_CSSON);
    SCB->VTOR = FLASH_BASE;
    __DSB();
    __ISB();
}
void SystemCoreClockUpdate(void)
{
    /* This project intentionally never changes the HSI /1 clock tree. */
    SystemCoreClock = 16000000u;
}
