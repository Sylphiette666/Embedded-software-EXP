#ifndef STM32F4XX_CONF_H
#define STM32F4XX_CONF_H
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_syscfg.h"
#include "stm32f4xx_exti.h"
#include "stm32f4xx_usart.h"
#include "misc.h"
#define assert_param(expr) ((void)0)
#endif
